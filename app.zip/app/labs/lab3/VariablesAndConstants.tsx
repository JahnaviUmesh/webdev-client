export default function VariablesAndConstants() {
    var functionScoped = 2;
    let blockScoped = 5;
    const constant1 = functionScoped - blockScoped;
    let myName = "Jahnavi";
    const greeting = `Hello, ${myName}! Welcome to the first on your own of lab 3!`;
    const sampleSum = functionScoped + blockScoped;
    return (
      <div id="wd-variables-and-constants">
        <h4>Variables and Constants</h4>
        functionScoped = {functionScoped} <br />
        blockScoped = {blockScoped}       <br />
        constant1 = {constant1}
        <br />
        myName = {myName}
        <br />
        greeting = {greeting}
        <br />
        sampleSum = {sampleSum}
        <hr />
      </div>
    );
}