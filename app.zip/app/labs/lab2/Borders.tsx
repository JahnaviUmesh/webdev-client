export default function Borders() {
    return (
      <div id="wd-css-borders">
        <h2>Borders</h2>
        <p className="wd-border-fat wd-border-red wd-border-solid">
          Solid fat red border
        </p>
        <p className="wd-border-thin wd-border-blue wd-border-dashed">
          Dashed thin blue border
        </p>
        <p id="wd-ai-border" className="wd-border-fat wd-border-dashed wd-border-yellow">
          Dashed fat yellow border
        </p>
        <p className="wd-border-fat wd-border-green wd-border-dashed">
          My personal dashed fat green border
        </p>
      </div>
    );
  }