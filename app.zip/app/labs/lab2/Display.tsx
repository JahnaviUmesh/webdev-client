export default function Display() {
    return (
      <div id="wd-css-display">
        <h2>Display</h2>
        <h3>Inline</h3>
        <div>
          <span className="wd-display-inline wd-bg-color-red">Inline 1</span>
          <span className="wd-display-inline wd-bg-color-yellow">Inline 2</span>
          <span className="wd-display-inline wd-bg-color-blue wd-fg-color-white">
            Inline 3
          </span>
        </div>
        <h3>Inline-block</h3>
        <div>
          <span className="wd-display-inline-block wd-bg-color-red">
            Inline-block 1
          </span>
          <span className="wd-display-inline-block wd-bg-color-yellow">
            Inline-block 2
          </span>
          <span className="wd-display-inline-block wd-bg-color-blue wd-fg-color-white">
            Inline-block 3
          </span>
        </div>
        <h3>Block</h3>
        <div>
          <span className="wd-display-block wd-bg-color-red">Block 1</span>
          <span className="wd-display-block wd-bg-color-yellow">Block 2</span>
          <span className="wd-display-block wd-bg-color-blue wd-fg-color-white">
            Block 3
          </span>
        </div>
        <div id="wd-ai-display" className="wd-display-inline wd-bg-color-green wd-fg-color-white">
          AI sample div displayed inline
        </div>
        <h3>Inline div with the width ignored</h3>
        <div>
            <div className="wd-display-inline wd-bg-color-red wd-fg-color-white">
            My personal box where this div is forced to display inline and so its width=150px is ignored and it only takes up as much space as it's text
            </div>
        </div>
      </div>
    );
}